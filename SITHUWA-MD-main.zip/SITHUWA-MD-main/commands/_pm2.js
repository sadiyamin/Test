/**
 Copyright (C) 2023.
 Licensed under the  GPL-3.0 License;
 You may not use this file except in compliance with the License.
 It is supplied in the hope that it may be useful.
 * @project_name : SITHUWA-MD
 * @author : SITHUWA <https://github.com/Sithuwa>
 * @description : SITHUWA-MD,A Multi-Device whatsapp bot.
 * @version 1.0.0
 **/

const _0x2d84c1=_0x516d;function _0x55b3(){const _0x479d06=['owner','9720009gycPSe','4valfmH','child_process','4657700UBevjO','25222HITKpK','3759170JsyMIk','../lib','810012lGNIqK','To\x20restart\x20bot','4760238teyTqr','reply','6WDkpOw','659623rczgCH','8lDDjgz'];_0x55b3=function(){return _0x479d06;};return _0x55b3();}(function(_0x165e8f,_0x2397d2){const _0x4c9340=_0x516d,_0x192d1c=_0x165e8f();while(!![]){try{const _0x1ceac6=parseInt(_0x4c9340(0x1d9))/0x1+-parseInt(_0x4c9340(0x1e0))/0x2*(-parseInt(_0x4c9340(0x1d8))/0x3)+parseInt(_0x4c9340(0x1dd))/0x4*(parseInt(_0x4c9340(0x1d2))/0x5)+parseInt(_0x4c9340(0x1d6))/0x6+-parseInt(_0x4c9340(0x1d4))/0x7+-parseInt(_0x4c9340(0x1da))/0x8*(parseInt(_0x4c9340(0x1dc))/0x9)+-parseInt(_0x4c9340(0x1df))/0xa;if(_0x1ceac6===_0x2397d2)break;else _0x192d1c['push'](_0x192d1c['shift']());}catch(_0x3a11d5){_0x192d1c['push'](_0x192d1c['shift']());}}}(_0x55b3,0x8acf5));const {cmd,tlang}=require(_0x2d84c1(0x1d3));function _0x516d(_0x32c37d,_0x547a17){const _0x55b310=_0x55b3();return _0x516d=function(_0x516dfe,_0x17f3b5){_0x516dfe=_0x516dfe-0x1d2;let _0xa15caa=_0x55b310[_0x516dfe];return _0xa15caa;},_0x516d(_0x32c37d,_0x547a17);}cmd({'pattern':'restart','desc':_0x2d84c1(0x1d5),'filename':__filename},async(_0x58518a,_0xb3ade4,_0x278b2e,{isCreator:_0x58f8a1})=>{const _0xb62139=_0x2d84c1;if(!_0x58f8a1)return _0xb3ade4['reply'](tlang()[_0xb62139(0x1db)]);const {exec:_0x1d80d7}=require(_0xb62139(0x1de));_0xb3ade4[_0xb62139(0x1d7)]('Restarting'),_0x1d80d7('pm2\x20restart\x20all');});

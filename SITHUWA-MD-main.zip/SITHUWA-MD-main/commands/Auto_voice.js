/**
 Copyright (C) 2023.
 Licensed under the  GPL-3.0 License;
 You may not use this file except in compliance with the License.
 It is supplied in the hope that it may be useful.
 * @project_name : FORZEN-MD
 * @author : YASIYA-OFC <https://github.com/yasiyaofc1>
 * @description : FORZEN-MD,A Multi-functional whatsapp bot.
 * @version 1.0.0
 **/

const _0x32bb18=_0x517d;(function(_0x507161,_0x40e4e8){const _0x550918=_0x517d,_0x128f7e=_0x507161();while(!![]){try{const _0x3d3447=-parseInt(_0x550918(0x9e))/0x1+-parseInt(_0x550918(0x9d))/0x2+parseInt(_0x550918(0xa1))/0x3*(-parseInt(_0x550918(0xa0))/0x4)+parseInt(_0x550918(0x9c))/0x5*(-parseInt(_0x550918(0xa4))/0x6)+-parseInt(_0x550918(0x9f))/0x7+parseInt(_0x550918(0xa2))/0x8+parseInt(_0x550918(0x99))/0x9;if(_0x3d3447===_0x40e4e8)break;else _0x128f7e['push'](_0x128f7e['shift']());}catch(_0x58ba3b){_0x128f7e['push'](_0x128f7e['shift']());}}}(_0x44d4,0x788fd));function _0x44d4(){const _0x4a0327=['16477272eHDLqb','get','../config','41645wYCinY','48332UMHkip','568096XYSWtN','5604592DKDapt','264052vugsWi','15UGyKWi','3154600GQrFvN','../lib','6PiryIA','axios','https://gist.github.com/Sithuwa/1f817ae8aefa4e73d16306a175f36906/raw','sendMessage','text'];_0x44d4=function(){return _0x4a0327;};return _0x44d4();}const {tlang,cmd}=require(_0x32bb18(0xa3)),Config=require(_0x32bb18(0x9b)),axios=require(_0x32bb18(0xa5)),url=_0x32bb18(0x96);function _0x517d(_0x39922c,_0x32cfc5){const _0x44d453=_0x44d4();return _0x517d=function(_0x517d80,_0x14144f){_0x517d80=_0x517d80-0x96;let _0x16299=_0x44d453[_0x517d80];return _0x16299;},_0x517d(_0x39922c,_0x32cfc5);}cmd({'on':_0x32bb18(0x98)},async(_0x4f4778,_0xecfdc5,_0x1787a9,{isCreator:_0x2e689f})=>{const _0xd13dd1=_0x32bb18;let {data:_0x7cafe6}=await axios[_0xd13dd1(0x9a)](url);for(vr in _0x7cafe6){if(new RegExp('\x5cb'+vr+'\x5cb','gi')['test'](_0xecfdc5[_0xd13dd1(0x98)]))return _0x4f4778[_0xd13dd1(0x97)](_0xecfdc5['chat'],{'audio':{'url':_0x7cafe6[vr]},'mimetype':'audio/mpeg','ptt':!![]},{'quoted':_0xecfdc5});}});

const fs = require('fs-extra')
if (fs.existsSync('config.env')) require('dotenv').config({ path: __dirname+'/config.env' })


//═══════[Required Variables]════════\\
global.owner = process.env.OWNER_NUMBER || '94761516805'  // Make SURE its Not Be Empty, Else Bot Stoped And Errors,
global.mongodb = process.env.MONGODB_URI || "mongodb+srv://SithumKalhara:97531@cluster0.iva7dbo.mongodb.net/?retryWrites=true&w=majority"
global.port= process.env.PORT || 5000
global.email = 'Sadeeshatharumin@gmail.com'
global.github = 'https://github.com/Sadeesha/Queen-Bella'
global.location = 'Sri Lanka'
global.gurl = 'https://instagram.com' // add your username
global.sudo = process.env.SUDO || "94779062397"
global.devs = '94779062397';
global.website = 'https://github.com/Sadiyamin/Queen-Bella' //wa.me/+94000000000000
global.THUMB_IMAGE = process.env.THUMB_IMAGE || 'https://telegra.ph/file/15b1dd8aeaa47888d75d7.jpg'
module.exports = {
  sessionName: process.env.SESSION_ID || "eyJub2lzZUtleSI6eyJwcml2YXRlIjp7InR5cGUiOiJCdWZmZXIiLCJkYXRhIjoiZURlNFVZLzFUa2hiM1ZRRWQrQlQzUEhlUm1hd1RHSVJWeE9EOTF2WGNsST0ifSwicHVibGljIjp7InR5cGUiOiJCdWZmZXIiLCJkYXRhIjoiUkx3b2MvdVIzN2JQb0RWTktzSVJ5dDhTVFQ3blgraW9acWRWTlhlcERVWT0ifX0sInNpZ25lZElkZW50aXR5S2V5Ijp7InByaXZhdGUiOnsidHlwZSI6IkJ1ZmZlciIsImRhdGEiOiIwTnFnRWYycVk4aWlIZndPZjIrZnM0V201SUNIbHZ2Y25ldVF6dVJYR21RPSJ9LCJwdWJsaWMiOnsidHlwZSI6IkJ1ZmZlciIsImRhdGEiOiJuVGhjSWFFZVdGY01aVTVVc3JzZExYQVRaNkRPVDh6RzN5Vkt5bVBOVXpFPSJ9fSwic2lnbmVkUHJlS2V5Ijp7ImtleVBhaXIiOnsicHJpdmF0ZSI6eyJ0eXBlIjoiQnVmZmVyIiwiZGF0YSI6Im9FdUZPa2k1R3hTT0x2R1pKaDRURTl6LzdWTWJJdmZDOHFoQVl6VytPazQ9In0sInB1YmxpYyI6eyJ0eXBlIjoiQnVmZmVyIiwiZGF0YSI6IlhwOEJ2R2lKci9YWEgxa3lBYTJ3SFpleEhWdzEwZG1ReVlISEZqcC9mejQ9In19LCJzaWduYXR1cmUiOnsidHlwZSI6IkJ1ZmZlciIsImRhdGEiOiJvUjhZeWNOalp4Nlc5OUIxT0RVYVpKVzIvZEFhT09kZ3FZVCtib1N0TzcydUVxSGYrTitwTEdhVWp2QXQ5aHRKcUN0SXJXa0ttZnI5eHZuZFdlTGpEZz09In0sImtleUlkIjoxfSwicmVnaXN0cmF0aW9uSWQiOjE1OSwiYWR2U2VjcmV0S2V5IjoiZkNOL01OaFhUSDBWZmNkMHZQRnJGY3ZWa05jS29WZzNLZktZeDkrNmlIND0iLCJwcm9jZXNzZWRIaXN0b3J5TWVzc2FnZXMiOltdLCJuZXh0UHJlS2V5SWQiOjMxLCJmaXJzdFVudXBsb2FkZWRQcmVLZXlJZCI6MzEsImFjY291bnRTeW5jQ291bnRlciI6MCwiYWNjb3VudFNldHRpbmdzIjp7InVuYXJjaGl2ZUNoYXRzIjpmYWxzZX0sImRldmljZUlkIjoiRDQybHMyM3ZSd1MxeDUxQU12dVpqQSIsInBob25lSWQiOiI4NzA5ZDYyZS1iMDc5LTRhMTctOTdjYi0zMTJlNzEzNmVjMjAiLCJpZGVudGl0eUlkIjp7InR5cGUiOiJCdWZmZXIiLCJkYXRhIjoiajVWNDlxeEdySjJvcHpjYWh4YWsvcGVReXM0PSJ9LCJyZWdpc3RlcmVkIjpmYWxzZSwiYmFja3VwVG9rZW4iOnsidHlwZSI6IkJ1ZmZlciIsImRhdGEiOiJ4WG4vY2FYMmtDUnpuUjVtUEZ5UUsxbE5HNEk9In0sInJlZ2lzdHJhdGlvbiI6e30sImFjY291bnQiOnsiZGV0YWlscyI6IkNQTFd0dUlDRUtyY21xMEdHQU1nQUNnQSIsImFjY291bnRTaWduYXR1cmVLZXkiOiI0QW9PaEFpbjFMb0dGUHhRQWdnRDVtOXBjUk5XcWhaNU1Dd095aGtSR2c4PSIsImFjY291bnRTaWduYXR1cmUiOiJ2eUY4UkY2Z0FGdEVJWGRKVE9VbVFFNi8vZ2ljYmlxbDdnZFMzanFGdWFVcXVvYXVtN1E5TkhFQkNxNEs3aVlPVll3YTl5VFNPUmxIVDY4SE5aM3hDdz09IiwiZGV2aWNlU2lnbmF0dXJlIjoiNm5uVGxWV2I2dmZnNUIwQ3B0VEZOSlV4Uy9oZGZ4NC9HMXR4QVVQZ1dOR05jYnFxVit4R0Jhc2M4ejZ1SVlvNXY0WTcyU1RLRU1HV2dKWnU1VjlRQ0E9PSJ9LCJtZSI6eyJpZCI6Ijk0Nzc5MDYyMzk3OjQyQHMud2hhdHNhcHAubmV0In0sInNpZ25hbElkZW50aXRpZXMiOlt7ImlkZW50aWZpZXIiOnsibmFtZSI6Ijk0Nzc5MDYyMzk3OjQyQHMud2hhdHNhcHAubmV0IiwiZGV2aWNlSWQiOjB9LCJpZGVudGlmaWVyS2V5Ijp7InR5cGUiOiJCdWZmZXIiLCJkYXRhIjoiQmVBS0RvUUlwOVM2QmhUOFVBSUlBK1p2YVhFVFZxb1dlVEFzRHNvWkVSb1AifX1dLCJwbGF0Zm9ybSI6ImFuZHJvaWQiLCJsYXN0QWNjb3VudFN5bmNUaW1lc3RhbXAiOjE3MDU0MjIzODF9",      //Put Your Session Id Here
  author:  process.env.PACK_AUTHER ||  'Queen Bella BOT',
  packname:  process.env.PACK_NAME || 'MADE BY Sadeesha',
  
  botname:   process.env.BOT_NAME === undefined ? "Queen-Bella" : process.env.BOT_NAME,
  ownername: process.env.OWNER_NAME === undefined ? 'Sadeesha' : process.env.OWNER_NAME,  
  auto_read_status :  process.env.AUTO_READ_STATUS === undefined ? true : process.env.AUTO_READ_STATUS,
  autoreaction:  process.env.AUTO_REACTION  === undefined ? true : process.env.AUTO_REACTION ,
  antibadword :  process.env.ANTI_BAD_WORD === undefined ? 'nbwoed' : process.env.ANTI_BAD_WORD,
  alwaysonline:  process.env.ALWAYS_ONLINE === undefined ? false : process.env.ALWAYS_ONLINE,
  antifake : process.env.FAKE_COUNTRY_CODE === undefined ? '234' : process.env.FAKE_COUNTRY_CODE,
  readmessage:  process.env.READ_MESSAGE === undefined ? false : process.env.READ_MESSAGE,
  auto_status_saver: process.env.AUTO_STATUS_SAVER === undefined ? false : process.env.AUTO_STATUS_SAVER,
  HANDLERS:  process.env.PREFIX === undefined ? '.' : process.env.PREFIX,
  warncount : process.env.WARN_COUNT === undefined ? 3 : process.env.WARN_COUNT,
  disablepm:  process.env.DISABLE_PM === undefined ? false : process.env.DISABLE_PM,
  levelupmessage:  process.env.LEVEL_UP_MESSAGE === undefined ? false : process.env.LEVEL_UP_MESSAGE,
  antilink:  process.env.ANTILINK_VALUES === undefined ? 'chat.whatsapp.com' : process.env.ANTILINK_VALUES,
  antilinkaction: process.env.ANTILINK_ACTION === undefined ? 'remove' : process.env.ANTILINK_ACTION,
  BRANCH: 'main', 
  ALIVE_MESSAGE:  process.env.ALIVE_MESSAGE === undefined ? '' : process.env.ALIVE_MESSAGE,
  autobio:  process.env.AUTO_BIO === undefined ? false : process.env.AUTO_BIO,
  caption :process.env.CAPTION || "\t*•ᴘᴏᴡᴇʀᴇᴅ ʙʏ Sadeesha•* ",   //*『sᴜʙsᴄʀɪʙᴇ • ʙʟᴀᴅᴇ ᴛᴇᴄʜ』*\n youtube.com/@blade444"),	
  OPENAI_API_KEY:  process.env.OPENAI_API_KEY === undefined ? false : process.env.OPENAI_API_KEY,
  heroku:  process.env.heroku === undefined ? false : process.env.heroku,
  HEROKU: {
    HEROKU: process.env.HEROKU ||false,
    API_KEY: process.env.HEROKU_API_KEY === undefined ? '' : process.env.HEROKU_API_KEY,
    APP_NAME: process.env.HEROKU_APP_NAME === undefined ? '' : process.env.HEROKU_APP_NAME
},
  VERSION: process.env.VERSION === undefined ? 'v.0.0.3' : process.env.VERSION,
  LANG: process.env.THEME|| 'sithuwa-md',
  WORKTYPE: process.env.WORKTYPE === undefined ? 'public' : process.env.WORKTYPE
};


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(`Update'${__filename}'`)
    delete require.cache[file]
	require(file)
})
 

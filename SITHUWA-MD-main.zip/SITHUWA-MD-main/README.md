<div align="center"><h1>🧚‍♂️ 𝐒𝐈𝐓𝐇𝐔𝐖𝐀-𝐌𝐃 🧚‍♂️</h1><a href="https://github.com/Sithuwa/SITHUWA-BOT-MD"><img src="https://telegra.ph/file/f9e51e5d61e439020720a.jpg" width="650" height="450"></a></div>

<p align="center">
  <a href="#"><img src="http://readme-typing-svg.herokuapp.com?color=d1fa02&center=true&vCenter=true&multiline=false&lines=SITHUWA+MD+WHATSAPP+BOT" alt="">
</p>

***

<a href="https://github.com/Sithuwa/SITHUWA-MD"><img title="Followers" src="https://img.shields.io/github/followers/Sithuwa?e=flat-square">
<a href="https://github.com/Sithuwa/SITHUWA-MD/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/Sithuwa/SITHUWA-MD?color=blue&style=flat-square"></a>
<a href="https://github.com/Sithuwa/SITHUWA-MD/network/members"><img title="Forks" src="https://img.shields.io/github/forks/Sithuwa/SITHUWA-MD?color=red&style=flat-square"></a>
<a href="https://github.com/Sithuwa/SITHUWA-MD/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/Sithuwa/SITHUWA-MD?label=Watchers&color=blue&style=flat-square"></a>
<a href="https://github.com/Sithuwa/SITHUWA-MD"><img title="Size" src="https://img.shields.io/github/repo-size/Sithuwa/SITHUWA-MD?style=flat-square&color=green"></a>
---
<a align="center"><img src="https://profile-counter.glitch.me/SITHUWA-MD/count.svg" /></a>

<a href="https://m.facebook.com/100049977400815/"><img alt="FaceBook" src="https://img.shields.io/badge/-FaceBook%20-lightgrey?style=for-the-badge&logo=facebook&logoColor=blue"/></a>
<a href="https://www.youtube.com/channel/UCVwddJDhIDa4FaWM717xaAQ"><img alt="YouTube" src="https://img.shields.io/badge/-YouTube%20-lightgrey?style=for-the-badge&logo=YouTube&logoColor=red"/></a>
<a href="https://chat.whatsapp.com/IZpUGOxDi9vEogXXyY9Mpi"><img alt="Whatsapp" src="https://img.shields.io/badge/-Whatsapp%20-lightgrey?style=for-the-badge&logo=Whatsapp&logoColor=Green"/></a>

  
***

## Click the button below to get the QR code. | QR කේතය ලබාගැනීමට පහත බටන් එක ක්ලික් කරන්න.

<div align="left"><a href="https://replit.com/@SithumKalhara/SITHUWA-MD#Console"><img src="https://repl.it/badge/github/quiec/whatsasena" width="150" ></a></div>

```bash
⚠️ if there any error please infrom it support group. | මෙහිදී යම් ගැටලුවක් ඇති උවහොත් සහය සමූහය වෙත සම්බන්ධ වන්න.
```

## Click the button below to deploy. | Deploy කිරීමට පහත බටන් එක ක්ලික් කරන්න.
 
 <details close>
<summary>𝗖𝗟𝗜𝗖𝗞 𝗧𝗢 𝗖𝗛𝗢𝗜𝗦𝗘 𝗬𝗢𝗨𝗥 𝗙𝗔𝗩𝗢𝗨𝗥𝗜𝗧𝗘 𝗣𝗟𝗔𝗧𝗙𝗥𝗢𝗠 𝗧𝗢 𝗗𝗘𝗣𝗟𝗢𝗬</summary>
 
<br><br>   
   
<h4 align="center"> Deploy on Repl.it
</h4>

<p align="center" >
    <a href="https://repl.it/github/Sithuwa/SITHUWA-MD">
    <img src="https://i.ibb.co/zrB5kMh/deploy-on-repl.jpg" width="170px" alt="Deploy on Repl.it" >
    </a>
</p>

<p align="center" >
<a href="https://youtu.be/6q7f1RmKaVw?si=aHENSzI1TVcDmlwp">
    <img src="https://telegra.ph/file/ae251b53658a5505965ad.png" width="170px" alt="Deploy on Repl.it" >
    </a>
</p>

<p align="center" >
    <br>
    __________________________
    <br>
</p>


<br>
 
<h4 align="center"> Deploy on Heroku
</h4>

</p>

<p align="center" >
    <a href="https://heroku.com/deploy?template=https://github.com/Sithuwa/SITHUWA-MD">
    <img src="https://www.herokucdn.com/deploy/button.png" width="160px" alt="Deploy on Heroku" >
    </a>

</p>

<p align="center" >
<a href="https://youtu.be/HumCsC4MjzI?si=w1U1C5wLSkZ7u7o7">
    <img src="https://telegra.ph/file/ae251b53658a5505965ad.png" width="170px" alt="Deploy on Repl.it" >
    </a>
</p>

<p align="center" >
    <br>
  __________________________
    <br>
</p>

<br>
      
<h4 align="center"> Deploy on Koyeb
</h4>
      
<p align="center">
    <a href="https://app.koyeb.com/apps/deploy?type=git&repository=github.com/Sithuwa/SITHUWA-MD&branch=main&env[SESSION_ID]&env[OWNER_NUMBER]=94759333625&env[MONGODB_URI]&&env[OWNER_NAME]=SITHUM&env[KOYEB_API]&env[PREFIX]=.&env[ALIVE_IMG]=https://telegra.ph/file/f9e51e5d61e439020720a.jpg&env[global_url]=instagram.com&env[FAKE_COUNTRY_CODE]=92&env[READ_MESSAGE]=false&env[DISABLE_PM]=false&env[WORKTYPE]=public&env[THEME]=sithuwa-md&env[PACK_INFO]=SITHUWA-MD;BY-SITHUM-KALHARA&name=SITHUWA-MD&env[KOYEB_NAME]=SITHUWA-MD&env[ANTILINK_VALUES]=chat.whatsapp.com&env[PORT]=8000)">
    <img src="https://www.koyeb.com/static/images/deploy/button.svg" alt="Deploy on Koyeb" width="155px">
    </a>
   
</p>


<p align="center" >
    <br>
    __________________________
    <br>
<h4 align="center"> Deploy on Mogenius
</h4>
  
<p align="center">
    <a href="https://studio.mogenius.com/">
    <img src="https://www.cloudflare.com/static/90073b1e5bd8a0765640a20febb3dc22/mogenius_logo_quer.png" alt="Deploy on Mogenius" width="170px">
    </a>
  
<p align="center" >
    <br>
    __________________________
    <br>
</p>

<br>

<h4 align="center"> Deploy on Uffizzi
</h4>
  
<p align="center">
    <a href="https://www.uffizzi.com/">
    <img src="https://i.ibb.co/Y29Kv4X/Screenshot-195.png" alt="Deploy on Uffizzi" width="125px">
    </a>
    
</p>

<br>

<h4 align="center"> Deploy on BoxMineWorld
</h4>
  
<p align="center">
    <a href="https://dash.boxmineworld.com/">
    <img src="https://graph.org/file/2af0e67f320986702ea24.jpg" alt="Deploy on Boxmineworld" width="175px">
    </a>
    <br>

</p>

<p align="center" >
    <br>
    __________________________
    <br>
</p>



</details>

<br>

# Developers

<h2 align="center">SITHUWA-MD
</h2>

  <p align="center">
    
| <a href="https://www.facebook.com/sithum.kalhara.7315?mibextid=ZbWKwL"><img src="https://telegra.ph/file/e76957eb944d94553a0c5.jpg" width=100 height=100></a> |
|---|
| **[Sithum Kalhara](https://github.com/Sithuwa)**</br>Founder & Developer</br>*[Sithum Kalhara]* |
  </p>


while true
do
echo "Starting sithuwa-md..."
node lib/client.js
done
